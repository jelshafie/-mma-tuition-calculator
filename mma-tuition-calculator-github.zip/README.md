# MMA Tuition Calculator (GitHub Pages)

A simple, working tuition calculator for Massanutten Military Academy.

- Base tuition fixed at **$36,500**
- **Aid %** (0–20%) reduces principal before interest
- **10‑month** fixed payment plan
- **Interest modes:**
  - **6% APR**, compounded monthly
  - **6% per month**, compounded monthly (very high; ≈101% APR)
- Uses standard amortization: `PMT = P * r / (1 - (1+r)^-n)` with `n=10`

## Quick Start (GitHub Pages)

1. Create a new repository on GitHub (e.g., `mma-tuition-calculator`).
2. Upload the **index.html** file from this project to the root of the repo.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` (or `master`), folder `/root`
5. Save. In 1–2 minutes, your site will be live at:

```
https://<your-username>.github.io/<your-repo-name>/
```

## How to Use

1. Enter **Aid %** (0–20%).
2. Choose **Interest** mode (6% APR or 6%/month).
3. Click **Calculate** to see:
   - **Aid amount (annual)**
   - **Tuition after aid (principal)**
   - **Monthly payment** (10 months, interest included)

## Notes

- If you need to change the base tuition, edit the `base` constant in `index.html`.
- For embedding on another site, you can iframe your GitHub Pages URL:

```html
<iframe src="https://<your-username>.github.io/<your-repo-name>/"
        width="100%" height="520" style="border:0;border-radius:12px;"></iframe>
```

MIT licensed. Customize as needed.
